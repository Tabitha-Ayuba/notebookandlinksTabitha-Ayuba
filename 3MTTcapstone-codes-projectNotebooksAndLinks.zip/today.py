#!/usr/bin/env python
# coding: utf-8

# In[3]:


# Importing necessary libraries
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import mean_squared_error
from statsmodels.tsa.arima.model import ARIMA
from prophet import Prophet



# In[4]:


# Load the dataset
df=pd.read_csv('C:/Users/HP/Desktop/cv19data.csv')
df


# In[5]:


# Step 2: Data Cleaning
# Dropping duplicates
df.drop_duplicates(inplace=True)



# In[6]:


# Checking for missing values
missing_values = df.isnull().sum()
df.fillna(0, inplace=True)


# In[7]:


# Converting Date column to datetime
df['Date'] = pd.to_datetime(df['Date'])


# In[8]:


# Ensuring numeric columns are in the correct format
numeric_columns = ['Confirmed', 'Deaths', 'Recovered', 'Active', 'New cases', 'New deaths', 'New recovered']
df[numeric_columns] = df[numeric_columns].apply(pd.to_numeric, errors='coerce').fillna(0)


# In[9]:


# Calculate daily growth rate as the percentage change in confirmed cases
df['Growth_Rate'] = df.groupby('Country/Region')['Confirmed'].pct_change() * 100


# In[10]:


# Mortality ratio as a percentage
df['Mortality_Rate'] = (df['Deaths'] / df['Confirmed']) * 100


# In[11]:


# Handle cases where Confirmed is 0 to avoid division by zero
df['Mortality_Rate'] = df['Mortality_Rate'].replace([np.inf, -np.inf], 0).fillna(0)


# In[12]:


# Calculate Total Cases (Active + Recovered + Deaths)
df['Total Cases	'] = df['Active'] + df['Recovered'] + df['Deaths']


# In[13]:


# Handle potential ZeroDivisionError
df['Growth_Rate'] = df['Growth_Rate'].replace(0, np.nan)  # Replace 0 with NaN


# In[14]:


# Derive Population (using a placeholder calculation for now)
# Replace this with a more accurate calculation if you have external population data
df['population'] = df['Confirmed'] / df['Growth_Rate'] 
df['population'] = df['population'].fillna(0)  # Fill NaN with 0
df['population']


# In[15]:


df.columns


# In[16]:


print(df['population'].isnull().sum())


# In[17]:


#check for zoro or negative value
print(df[df['population']<=0])


# In[18]:


# Step 2: Reset index to avoid indexing issues
df.reset_index(drop=True, inplace=True)


# In[19]:


# Step 1: Inspect Population column for NaN, negative, or zero values
print("population Column Type:", df['population'].dtype)
print("Missing Values:", df['population'].isnull().sum())
print("Zero or Negative Values:", df[df['population'] <= 0])


# In[20]:


# Display Results
print(df[['Date', 'Country/Region', 'Total Cases\t', 'population']])


# In[21]:


# Calculate infection rate
df['Infection Rate (%)'] = (df['Confirmed'] / df['population'])


# In[22]:


# Calculate cases per 100,000 population
df['Cases_Per_100k'] = (df['Confirmed'] / df['population']) * 100_000


# In[23]:


# Handle missing or zero population values
df['Cases_Per_100k'] = df['Cases_Per_100k'].fillna(0)


# In[24]:


# Recovery Rate (Recovered Cases per Confirmed Cases)
df['Recovery_Rate'] = (df['Recovered'] / df['Confirmed']) * 100


# In[25]:


# Handle cases where Confirmed is 0
df['Recovery_Rate'] = df['Recovery_Rate'].replace([np.inf, -np.inf], 0).fillna(0)


# In[26]:


#  Active Cases Ratio (Active Cases per Confirmed Cases)
df['Active_Ratio'] = (df['Active'] / df['Confirmed']) * 100
df['Active_Ratio'] = df['Active_Ratio'].replace([np.inf, -np.inf], 0).fillna(0)



# In[27]:


# Display the first few rows of the dataset with new variables
print(df[['Date', 'Country/Region', 'Confirmed', 'Deaths', 'Recovered', 
          'Growth_Rate', 'Mortality_Rate', 'Cases_Per_100k', 'Recovery_Rate', 'Active_Ratio']].head())


# In[28]:


# Display all unique countries/regions in the dataset
unique_countries = df['Country/Region'].unique()
print("Unique Country/Regions:")
print(unique_countries)


# In[29]:


# Exploratory Data Analysis (EDA)
# Plotting total confirmed cases over time globally
plt.figure(figsize=(12, 6))
df.groupby('Date')['Confirmed'].sum().plot()
plt.title("Global Confirmed Cases Over Time")
plt.xlabel("Date")
plt.ylabel("Number of Cases")
plt.grid(True)
plt.show()


# In[30]:


# Plotting New Cases globally over time
plt.figure(figsize=(12, 6))
df.groupby('Date')['New cases'].sum().plot(color='orange')
plt.title("Global New Cases Over Time")
plt.xlabel("Date")
plt.ylabel("New Cases")
plt.grid(True)
plt.show()


# In[31]:


# Top 10 countries with the highest confirmed cases
top_countries = df.groupby('Country/Region')['Confirmed'].max().sort_values(ascending=False).head(10)
plt.figure(figsize=(12, 6))
sns.barplot(x=top_countries.index, y=top_countries.values, palette="coolwarm")
plt.title("Top 10 Countries by Confirmed Cases")
plt.ylabel("Confirmed Cases")
plt.xticks(rotation=45)
plt.show()


# In[32]:


#  Predictive Modeling
# Aggregating data for time-series forecasting
time_series = df.groupby('Date')[['Confirmed', 'Deaths', 'Recovered']].sum().reset_index()



# In[33]:


# Preparing data for ARIMA
arima_data = time_series.set_index('Date')['Confirmed']


# In[56]:


# Add time-based features (if relevant)
df['Year'] = df['Date'].dt.year
df['Month'] = df['Date'].dt.month
df['Day'] = df['Date'].dt.day



# In[39]:


#  Data Splitting (For regression and machine learning tasks)
X = df[['population', 'Confirmed', 'Infection Rate (%)', 'Year', 'Month', 'Day']]
y = df['Confirmed']  # Target variable: Confirmed cases



# In[40]:


# Split into training and test sets
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)



# In[71]:


# Step 1: Group by 'Date' and aggregate data
grouped_data = df.groupby('Date',as_index=False).agg({
    'Confirmed': 'sum',
    'Deaths': 'sum',
    'Recovered': 'sum',
    'Active': 'sum',
    'New cases': 'sum',
    'New deaths': 'sum',
    'New recovered': 'sum',
    'Growth_Rate': 'mean',  # Mean as an example
    'Mortality_Rate': 'mean',  # Mean as an example
    'Infection Rate (%)': 'mean',  # Mean as an example
    'Cases_Per_100k': 'mean',  # Mean as an example
    'Recovery_Rate': 'mean',  # Mean as an example
    'Active_Ratio': 'mean',  # Mean as an example
    'population': 'mean',  # Mean as an example
    'Total Cases\t': 'sum',
})


# In[59]:


grouped_data.columns


# In[60]:


# Ensure 'Date' is in datetime format
grouped_data['Date'] = pd.to_datetime(grouped_data['Date'])



# In[50]:


grouped_data.set_index("Date",inplace=True)


# In[61]:


grouped_data_yearly = df.groupby(['Country/Region', 'Year']).agg({
    'Confirmed': 'sum',
    'Deaths': 'sum',
    'Recovered': 'sum',
    'New cases': 'sum',
    'New deaths': 'sum',
    'Growth_Rate': 'mean',
})



# In[47]:


# Step  Check for extreme values in the grouped data
print("Max value in grouped data:", np.max(grouped_data))
print("Min value in grouped data:", np.min(grouped_data))



# In[67]:


print (grouped_data.head())


# In[68]:


print (grouped_data.describe())


# In[69]:


print (grouped_data.isnull().sum())


# In[81]:


# Compute the correlation matrix
correlation_matrix = grouped_data[numeric_columns].corr()



# In[43]:


#After grouping, you can add calculated fields
grouped_data['Mortality Rate (%)'] = (grouped_data['Deaths'] / grouped_data['Confirmed']) * 100
grouped_data['Recovery Rate (%)'] = (grouped_data['Recovered'] / grouped_data['Confirmed']) * 100
grouped_data['Infection Rate (%)'] = (grouped_data['Confirmed'] / grouped_data['population']) * 100





# In[44]:


#You can compute the correlation matrix for the grouped data:

correlation_matrix = grouped_data.corr()



# In[82]:


# correlation with grouped_data
corr= grouped_data.corr()
corr["population"].sort_values(ascending=False)


# In[62]:


# Visualize the correlation matrix
import seaborn as sns
import matplotlib.pyplot as plt

plt.figure(figsize=(10, 8))
sns.heatmap(correlation_matrix, annot=True, cmap='coolwarm', fmt=".2f")
plt.title("COVID-19 Data Correlation Matrix")
plt.show()




# In[47]:


# Boxplot for detecting outliers in 'Confirmed' across countries/regions
plt.figure(figsize=(12, 6))
sns.boxplot(x='Country/Region', y='Confirmed', data=grouped_data)
plt.title('Outlier Detection for Confirmed Cases by Country/Region')
plt.xticks(rotation=90)
plt.show()



# In[63]:


# Plot the time series trend for Confirmed cases
plt.figure(figsize=(12, 6))
grouped_data.groupby('Date')['Confirmed'].sum().plot()
plt.title('Confirmed Cases Over Time (Grouped Data)')
plt.xlabel('Date')
plt.ylabel('Confirmed Cases')
plt.show()


# In[73]:


grouped_data = df.groupby('Country/Region',as_index=False).agg({
                           'Confirmed': 'sum',
    'Deaths': 'sum',
    'Recovered': 'sum',
    'Active': 'sum',
    'New cases': 'sum',
    'New deaths': 'sum',
    'New recovered': 'sum',
    'Growth_Rate': 'mean',  # Mean as an example
    'Mortality_Rate': 'mean',  # Mean as an example
    'Infection Rate (%)': 'mean',  # Mean as an example
    'Cases_Per_100k': 'mean',  # Mean as an example
    'Recovery_Rate': 'mean',  # Mean as an example
    'Active_Ratio': 'mean',  # Mean as an example
    'population': 'mean',  # Mean as an example
    'Total Cases\t': 'sum',
})


# In[74]:


# Bar plot for the number of cases by 'Country/Region'
grouped_data.groupby('Country/Region')['Confirmed'].sum().nlargest(10).plot(kind='bar')
plt.title('Top 10 Countries/Regions by Confirmed Cases')
plt.xlabel('Country/Region')
plt.ylabel('Total Confirmed Cases')
plt.xticks(rotation=90)
plt.show()



# In[76]:


# Get the top 10 countries by Confirmed cases
top_countries = grouped_data.nlargest(10, 'Confirmed')
print(top_countries)



# In[78]:


# Plot the data
plt.figure(figsize=(12, 6))
plt.bar(top_countries['Country/Region'], top_countries['Confirmed'], color='skyblue')
plt.title('Top 10 Countries/Regions by Confirmed Cases')
plt.xlabel('Country/Region')
plt.ylabel('Total Confirmed Cases')
plt.xticks(rotation=45)
plt.grid(axis='y')
plt.show()



# In[ ]:





# In[69]:


grouped_data.columns


# In[120]:


grouped_data=grouped_data.set_index()


# In[79]:


#size of plot
plt.figure(figsize=(12, 6))


# In[84]:


# Sort data by Infection Rate for better visualization
sorted_data = grouped_data.sort_values(by='Infection Rate (%)', ascending=False).head(10)  # Top 10 for readability





# In[85]:


# Top 10 for readability
plt.figure(figsize=(10, 6))
plt.bar(sorted_data['population'], sorted_data['Infection Rate (%)'], color='skyblue')
plt.title('Infection Rate (%) vs Population Size')
plt.xlabel('Population Size')
plt.ylabel('Infection Rate (%)')
plt.xticks(rotation=45)  # Rotate x-axis labels for better readability
plt.tight_layout()  # Adjust layout for clarity
plt.show()



# In[116]:


grouped_data.set_index("Date",inplace=True)


# In[115]:


grouped_data.columns


# In[51]:


from sklearn.preprocessing import StandardScaler


# In[90]:


# Reset index so 'Country/Region' becomes a column instead of an index
grouped_data = grouped_data.reset_index()


# In[114]:


# Step 7: Split the data into X (features) and y (target variable)
# Example: Assume we are predicting 'log_Confirmed' based on other features
X_train = grouped_data.drop(['log_Confirmed', 'Country/Region'], axis=1)  # Features
y_train = grouped_data['log_Confirmed']  # Target variable



# In[102]:


from sklearn.metrics import mean_squared_error, r2_score



# In[108]:


# Ensure y_test and y_pred are defined
# y_test: True labels for the test set
# y_pred: Predictions made by your model on the test set



# In[109]:


# Step 10: Make predictions using the trained model
predictions = rf_model.predict(X_train)


# In[110]:


# Evaluate model performance
mse = mean_squared_error(y_train, predictions)  # Mean Squared Error
rmse = np.sqrt(mse)  # Root Mean Squared Error
r2 = r2_score(y_train, predictions)  # R-squared


# In[111]:


# Print the evaluation metrics
print(f"Mean Squared Error: {mse}")
print(f"Root Mean Squared Error: {rmse}")
print(f"R-squared: {r2}")


# In[112]:


from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score


# In[126]:


# Group by Date
grouped_data = df.groupby('Date',as_index=False).agg({
                           'Confirmed': 'sum',
    'Deaths': 'sum',
    'Recovered': 'sum',
    'Active': 'sum',
    'New cases': 'sum',
    'New deaths': 'sum',
    'New recovered': 'sum',
    'Growth_Rate': 'mean',  # Mean as an example
    'Mortality_Rate': 'mean',  # Mean as an example
    'Infection Rate (%)': 'mean',  # Mean as an example
    'Cases_Per_100k': 'mean',  # Mean as an example
    'Recovery_Rate': 'mean',  # Mean as an example
    'Active_Ratio': 'mean',  # Mean as an example
    'population': 'mean',  # Mean as an example
    'Total Cases\t': 'sum',
})



# In[127]:


grouped_data.columns


# In[128]:


from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import mean_squared_error, accuracy_score, precision_score, recall_score, f1_score, classification_report
from statsmodels.tsa.arima.model import ARIMA


# In[129]:


# --- DATA PREPROCESSING ---
# Ensure Date is in datetime format and sorted
grouped_data['Date'] = pd.to_datetime(grouped_data['Date'])
grouped_data.sort_values(by='Date', inplace=True)



# In[130]:


# Create Lag Features for time series
grouped_data['Lag_1'] = grouped_data['New cases'].shift(1)
grouped_data['Lag_7'] = grouped_data['New cases'].shift(7)  # Weekly trend example
grouped_data.dropna(inplace=True)  # Drop rows with missing lag values


# In[131]:


# Create Lag Features for time series
grouped_data['Lag_1'] = grouped_data['New cases'].shift(1)
grouped_data['Lag_7'] = grouped_data['New cases'].shift(7)  # Weekly trend example
grouped_data.dropna(inplace=True)  # Drop rows with missing lag values



# In[132]:


# --- TIME SERIES FORECASTING ---
# Extract the time series
time_series = grouped_data[['Date', 'New cases']].set_index('Date')


# In[133]:


# Split data into training and test sets
train = time_series[:-30]  # Train on all but the last 30 days
test = time_series[-30:]   # Test on the last 30 days


# In[148]:


# Fit ARIMA model
model = ARIMA(train, order=(5,1, 0))  # Adjust p, d, q values
model_fit = model.fit()


# In[135]:


# Forecast
forecast = model_fit.forecast(steps=len(test))


# In[136]:


# Evaluate Time Series Forecast with RMSE
rmse = mean_squared_error(test, forecast, squared=False)
print(f"Time Series RMSE: {rmse:.2f}")


# In[137]:


# Convert forecast and test values to binary classes for evaluation
threshold = 0
forecast_classes = (forecast > threshold).astype(int)
test_classes = (test.values.flatten() > threshold).astype(int)


# In[139]:


# Evaluate classification metrics on the time series forecast
accuracy_ts = accuracy_score(test_classes, forecast_classes)
precision_ts = precision_score(test_classes, forecast_classes)
recall_ts = recall_score(test_classes, forecast_classes)
f1_ts = f1_score(test_classes, forecast_classes)

print("\n--- Time Series Classification Metrics ---")
print(f"Accuracy: {accuracy_ts:.2f}")
print(f"Precision: {precision_ts:.2f}")
print(f"Recall: {recall_ts:.2f}")
print(f"F1 Score: {f1_ts:.2f}")


# In[143]:


# --- CLASSIFICATION MODEL ---
# Features and Target
X = grouped_data[['Lag_1', 'Lag_7', 'Growth_Rate', 'Mortality_Rate']]  # Select relevant features
y = grouped_data['population']  # Binary target: 1 for increase, 0 for decrease


# In[144]:


# Train-Test Split
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)


# In[151]:


print(X_test.describe())


# In[152]:


X_train=np.log1p(X_train)
X_test=np.log1p(X_test)


# In[153]:


print(X_test.isnull().sum())
print(np.isinf(X_test).sum())


# In[154]:


X_train.fillna(0, inplace=True)  # Replace NaNs with 0
X_test.fillna(0, inplace=True)

X_train.replace([np.inf, -np.inf], 0, inplace=True)  # Replace Inf/-Inf with 0
X_test.replace([np.inf, -np.inf], 0, inplace=True)




# In[155]:


from sklearn.preprocessing import StandardScaler

scaler = StandardScaler()
X_train = scaler.fit_transform(X_train)
X_test = scaler.transform(X_test)




# In[156]:


# Check and handle missing/infinite values
X.fillna(0, inplace=True)
X.replace([np.inf, -np.inf], 0, inplace=True)


# In[157]:


# Scale features
from sklearn.preprocessing import StandardScaler
scaler = StandardScaler()
X_train = scaler.fit_transform(X_train)
X_test = scaler.transform(X_test)



# In[159]:


# Make Predictions
y_pred = clf.predict(X_test)



# In[ ]:




