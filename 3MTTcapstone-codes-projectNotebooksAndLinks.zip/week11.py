#!/usr/bin/env python
# coding: utf-8

# In[32]:


import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
import geopandas as gdp
from sklearn.preprocessing import MinMaxScaler




# In[33]:


# Load the dataset
df=pd.read_csv('C:/Users/HP/Desktop/cv19data.csv')
df


# In[34]:


# Convert 'date' column to datetime format
df['Date'] = pd.to_datetime(df['Date'])



# In[35]:


#remove any rows that contains zero values
df_cleaned=df[(df !=0).all(axis=1)]
print ("\nDataFrame after removing rows where any cell contains 0:")
print(df_cleaned)


# In[36]:


df_cleanedcopy=df_cleaned.copy()


# In[37]:


df_cleanedcopy.to_csv('C:/Users/HP/Desktop/df_cleanedcopy.csv',index=False)


# In[38]:


print(df_cleanedcopy.dtypes)


# In[39]:


#filter numeric columns only
numeric_df = df_cleanedcopy.select_dtypes(include=['float64', 'int64'])
numeric_df


# In[40]:


print(numeric_df.corr())


# In[41]:


# Generate full date range
full_date_range = pd.date_range(start=df_cleanedcopy['Date'].min(), end=df_cleanedcopy['Date'].max())



# In[42]:


#finding the minimun and maximun date
min_date = df_cleanedcopy['Date'].min()
max_date = df_cleanedcopy['Date'].max()

print(f'Date range:{min_date}to{max_date}')


# In[43]:


# Generate full date range
full_date_range = pd.date_range(start=df_cleanedcopy['Date'].min(), end=df_cleanedcopy['Date'].max())
full_date_range 



# In[44]:


print(df_cleanedcopy.columns)


# In[45]:


#Reset the index to bring the Date column back:
df_cleanedcopy.reset_index(inplace=True)
df_cleanedcopy.rename(columns={'index': 'Date'}, inplace=True)



# In[46]:


print(df_cleanedcopy)


# In[50]:


#Extract year, month, and day using .dt
df_cleanedcopy['Year'] = df_cleanedcopy['Date'].dt.year
df_cleanedcopy['Month'] = df_cleanedcopy['Date'].dt.month
df_cleanedcopy['Day'] = df_cleanedcopy['Date'].dt.day
print(df_cleanedcopy)


# In[48]:


# Active Cases = Confirmed - Deaths - Recovered
df_cleanedcopy['Active'] = df_cleanedcopy['Confirmed'] - df_cleanedcopy['Deaths'] - df_cleanedcopy['Recovered']


# In[ ]:


# Daily new cases, deaths, and recoveries
df_cleanedcopy['New_Confirmed'] = df_cleanedcopy.groupby('Country/Region')['Confirmed'].diff().fillna(0)
df_cleanedcopy['New_Deaths'] = df_cleanedcopy.groupby('Country/Region')['Deaths'].diff().fillna(0)
df_cleanedcopy['New_Recovered'] = df_cleanedcopy.groupby('Country/Region')['Recovered'].diff().fillna(0)


# In[ ]:


#Growth Rate of Confirmed Cases
# Avoid division by zero using a small epsilon
df_cleanedcopy['Growth_Rate'] = df_cleanedcopy['New_Confirmed'] / (df_cleanedcopy['Confirmed'].shift(1) + 1e-5)


# In[ ]:


#Mortality Rate

df_cleanedcopy['Mortality_Rate'] = df_cleanedcopy['Deaths'] / (df_cleanedcopy['Confirmed'] + 1e-5)


# In[ ]:


#Rolling Averages
# 7-day rolling average of new confirmed cases
df_cleanedcopy['Confirmed_Rolling7'] =df_cleanedcopy.groupby('Country/Region')['New_Confirmed'].rolling(window=7).mean().reset_index(0, drop=True)



# In[ ]:


#Lag Features
# Lag by 1 day
df_cleanedcopy['Confirmed_Lag1'] = df_cleanedcopy.groupby('Country/Region')['Confirmed'].shift(1)
df_cleanedcopy['Deaths_Lag1'] = df_cleanedcopy.groupby('Country/Region')['Deaths'].shift(1)
df_cleanedcopy['Recovered_Lag1'] = df_cleanedcopy.groupby('Country/Region')['Recovered'].shift(1)


# In[ ]:


# Binary features
# Example 1: Lockdown flag (for a specific country and date)
df_cleanedcopy['Is_Lockdown'] = ((df_cleanedcopy['Date'] >= '2020-03-15') & (df_cleanedcopy['Country/Region'] == 'China')).astype(int)



# In[ ]:


# Example 2: High cases threshold
df_cleanedcopy['High_Cases'] = (df_cleanedcopy['Confirmed'] > 1000).astype(int)


# In[ ]:


# Example 3: Specific country flag
df_cleanedcopy['Is_China'] = (df_cleanedcopy['Country/Region'] == 'China').astype(int)


# In[ ]:


# Fill missing values (if any remain after feature engineering)
df_cleanedcopy.fillna(0, inplace=True)



# In[63]:


# Save the enhanced dataset
df_cleanedcopy.to_csv('df_cleanedcopy_with_features.csv', index=False)



# In[69]:


# Output summary
df_cleanedcopy.to_csv('C:/Users/HP/Desktop/df_cleanedcopy_with_features.csv',index=False)


# In[70]:


df=pd.read_csv('C:/Users/HP/Desktop/df_cleanedcopy_with_features.csv')
df


# In[72]:


df.head()


# In[73]:


df.info


# In[74]:


df.describe


# In[75]:


# 2. Check for Missing Values
print("\nMissing values:")
print(df.isnull().sum())  # Count of missing values per column



# In[76]:


# Visualizing missing data
plt.figure(figsize=(10, 6))
sns.heatmap(df.isnull(), cbar=False, cmap='viridis')
plt.title('Missing Data Heatmap')
plt.show()


# In[78]:


# Univariate Analysis - Distribution of Key Features
# Visualize distributions for the numerical columns (e.g., 'Confirmed', 'Deaths', 'Recovered')
numerical_features = ['Confirmed', 'Deaths', 'Recovered', 'Active', 'New_Confirmed', 'New_Deaths', 'New_Recovered']
plt.figure(figsize=(14, 10))
for i, col in enumerate(numerical_features, 1):
    plt.subplot(3, 3, i)  # 3x3 grid for multiple plots
    sns.histplot(df[col], kde=True, color='blue', bins=30)
    plt.title(f'Distribution of {col}')
    plt.xlabel(col)
    plt.ylabel('Frequency')
plt.tight_layout()
plt.show()


# In[79]:


# 4. Correlation Analysis
# Visualizing correlations between numerical features
plt.figure(figsize=(12, 8))
correlation_matrix = df[numerical_features].corr()
sns.heatmap(correlation_matrix, annot=True, cmap='coolwarm', fmt='.2f', linewidths=0.5)
plt.title('Correlation Matrix')
plt.show()


# In[80]:


# Bivariate Analysis - Relationships Between Features
# Visualizing relationships between confirmed cases and other features
plt.figure(figsize=(14, 6))
sns.scatterplot(data=df, x='Confirmed', y='New_Confirmed', hue='Country/Region', palette='viridis')
plt.title('Confirmed vs New Confirmed Cases')
plt.xlabel('Confirmed Cases')
plt.ylabel('New Confirmed Cases')
plt.show()



# In[81]:


# Visualizing Confirmed vs Growth Rate
plt.figure(figsize=(14, 6))
sns.scatterplot(data=df, x='Confirmed', y='Growth_Rate', hue='Country/Region', palette='viridis')
plt.title('Confirmed vs Growth Rate')
plt.xlabel('Confirmed Cases')
plt.ylabel('Growth Rate')
plt.show()


# In[82]:


# Time Series Analysis (e.g., Confirmed cases over time for a specific country)
# Visualizing Confirmed vs Growth Rate
plt.figure(figsize=(14, 6))
sns.scatterplot(data=df, x='Confirmed', y='Growth_Rate', hue='Country/Region', palette='viridis')
plt.title('Confirmed vs Growth Rate')
plt.xlabel('Confirmed Cases')
plt.ylabel('Growth Rate')
plt.show()


# In[83]:


# Let's visualize the time trend for 'Confirmed' cases in China
china_data = df[df['Country/Region'] == 'China']
plt.figure(figsize=(14, 6))
sns.lineplot(data=china_data, x='Date', y='Confirmed', marker='o')
plt.title('Confirmed Cases Over Time (China)')
plt.xlabel('Date')
plt.ylabel('Confirmed Cases')
plt.xticks(rotation=45)
plt.show()


# In[85]:


# Categorical Analysis - Frequency of Categories (Country/Region)
plt.figure(figsize=(12, 6))
country_counts = df['Country/Region'].value_counts().head(10)  # Top 10 countries
sns.barplot(x=country_counts.index, y=country_counts.values, palette='Set2')
plt.title('Top 10 Countries by Confirmed Cases')
plt.xlabel('Country/Region')
plt.ylabel('Number of Confirmed Cases')
plt.xticks(rotation=45)
plt.show()


# In[86]:


#  Handling Outliers (if needed)
# Boxplots to detect outliers in 'Confirmed' and 'Deaths'
plt.figure(figsize=(14, 6))
plt.subplot(1, 2, 1)
sns.boxplot(x=df['Confirmed'], color='lightblue')
plt.title('Boxplot of Confirmed Cases')



# In[87]:


plt.subplot(1, 2, 2)
sns.boxplot(x=df['Deaths'], color='lightcoral')
plt.title('Boxplot of Deaths')
plt.tight_layout()
plt.show()


# In[88]:


# Pairplot for Relationships Between Multiple Features
# Visualizing pairwise relationships between numerical features
sns.pairplot(df[numerical_features], hue='Country/Region', palette='viridis', diag_kind='kde')
plt.suptitle('Pairplot of Numerical Features', y=1.02)
plt.show()



# In[89]:


# Advanced - Trendline for Growth Rate vs Confirmed Cases (for large countries)
large_countries = df[df['Confirmed'] > 50000]  # Filter for large countries (Confirmed > 50k)
plt.figure(figsize=(14, 6))
sns.regplot(data=large_countries, x='Confirmed', y='Growth_Rate', scatter_kws={'s': 20}, line_kws={'color': 'red'})
plt.title('Confirmed vs Growth Rate for Large Countries')
plt.xlabel('Confirmed Cases')
plt.ylabel('Growth Rate')
plt.show()


# In[91]:


print(df.head())


# In[94]:


print(df.columns)


# In[100]:


# Apply One-Hot Encoding to the categorical columns
df_encoded = pd.get_dummies(df, columns=['Country/Region', 'Date'], drop_first=True)


# In[110]:


print(df_encoded.dtypes)


# In[112]:


# Define Features (X) and Target (y)
# Replace 'Confirmed' with the actual target column name you found
X = df_encoded.drop(columns=['Confirmed'], axis=1)  # Drop irrelevant columns
y = df_encoded['Confirmed']  # Use 'Confirmed' as the target column


# In[113]:


#Check for any non-numeric columns in X (if any)
non_numeric_columns = X.select_dtypes(include=['object']).columns
if len(non_numeric_columns) > 0:
   print(f"Non-numeric columns found: {non_numeric_columns}")
   # Drop any non-numeric columns if present
   X = X.drop(columns=non_numeric_columns)



# In[114]:


# Handle Missing Values (if any)
X = X.fillna(0)  # Handle missing values by filling with 0 (adjust based on your data)



# In[116]:


#  Train-Test Split
from sklearn.model_selection import train_test_split
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)


# In[ ]:


# 4. Feature Scaling (optional, essential for some algorithms)
from sklearn.preprocessing import StandardScaler
scaler = StandardScaler()
X_train_scaled = scaler.fit_transform(X_train)
X_test_scaled = scaler.transform(X_test)


# In[ ]:





# In[ ]:




