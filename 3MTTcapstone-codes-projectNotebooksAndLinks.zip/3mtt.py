#!/usr/bin/env python
# coding: utf-8

# In[1]:


#Import necessary libraries
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.model_selection import train_test_split, GridSearchCV
from sklearn.preprocessing import StandardScaler, LabelEncoder
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score, confusion_matrix, classification_report
from sklearn.model_selection import train_test_split


# In[4]:


# Load the dataset
df=pd.read_csv('C:/Users/HP/Desktop/cv19data.csv')
df


# In[5]:


# Convert 'date' column to datetime format
df['Date'] = pd.to_datetime(df['Date'])


# In[6]:


#Extract year, month, and day using .dt
df['Year'] = df['Date'].dt.year
df['Month'] = df['Date'].dt.month
df['Day'] = df['Date'].dt.day
print(df)


# In[7]:


# Step 1: Assess Dataset Structure
df.shape



# In[8]:


df.info()  # Overview of dataset columns and non-null values



# In[9]:


df.head()  # Display first 5 rows


# In[10]:


#drop rows with missing values
df_cleaned = df.dropna()
df_cleaned


# In[11]:


# Display the cleaned dataframe
print("Rows with missing values removed:")
print(df_cleaned.head())




# In[106]:


# Remove Duplicates
# Check and remove any duplicate rows
print("\nDuplicate Rows Before Removing:", df.duplicated().sum())
df = df.drop_duplicates()
print("Duplicate Rows After Removing:", df.duplicated().sum())


# In[107]:


# Standardize Numerical Data (Scaling)
# If you have numerical columns that need to be standardized
numerical_columns = df.select_dtypes(include=['float64', 'int64']).columns
scaler = StandardScaler()
df[numerical_columns] = scaler.fit_transform(df[numerical_columns])


# In[14]:


#filter numeric columns only
numeric_df = df_cleaned.select_dtypes(include=['float64', 'int64'])
numeric_df


# In[15]:


print(numeric_df.corr())


# In[108]:


#Calculate correlation matrix and visualize it
correlation_matrix = df_cleaned[['Confirmed', 'Deaths', 'Recovered', 'Active', 'New cases', 'New deaths', 'New recovered']].corr()
plt.figure(figsize=(10, 6))
sns.heatmap(correlation_matrix, annot=True, cmap='coolwarm', fmt='.2f', linewidths=0.5)
plt.title('Correlation Matrix for Key Factors')
plt.show()



# In[17]:


from sklearn.decomposition import PCA
from sklearn.linear_model import LinearRegression


# In[113]:


#Calculate transmission rate (cases per population or cases per tests)
# If you have a population column, replace it, or use 'Confirmed' or 'Active' cases for analysis
# df_cleaned['transmission_rate'] = df_cleaned['Confirmed'] / df_cleaned['Population'] # if Population data exists
# For now, let's calculate the active cases ratio as a proxy for transmission rate
df_cleaned['transmission_rate'] = df_cleaned['Active'] / df_cleaned['Confirmed']
df_cleaned['transmission_rate'] = df_cleaned['transmission_rate'].fillna(0)  # Handle potential NaN values




# In[111]:


# Group-wise aggregation by countries/regions
group_by_country = df_cleaned.groupby('Country/Region')[['transmission_rate', 'Confirmed', 'Deaths', 'Recovered', 'Active', 'New cases', 'New deaths', 'New recovered']].mean()
print("\nGroup-wise Transmission Rate Analysis by Country/Region:")
print(group_by_country)



# In[112]:


#  Perform regression analysis to identify key factors
X = df_cleaned[['Confirmed', 'New cases', 'New deaths', 'New recovered']]  # Independent variables
y = df_cleaned['transmission_rate']  # Dependent variable




# In[23]:


# Linear Regression
model = LinearRegression()
model.fit(X, y)
print("\nLinear Regression Coefficients:")
print(f"Coefficients: {model.coef_}")
print(f"Intercept: {model.intercept_}")



# In[24]:


# Time-series analysis (assuming the dataset has a 'Date' column)
df_cleaned['Date'] = pd.to_datetime(df_cleaned['Date'])  # Convert to datetime format if not already
df_cleaned.set_index('Date', inplace=True)






# In[25]:


from sklearn.ensemble import RandomForestRegressor



# In[115]:


# Train Random Forest model for feature importance
rf_model = RandomForestRegressor(n_estimators=100, random_state=42)
rf_model.fit(X, y)


# In[27]:


# Feature importance
feature_importance = rf_model.feature_importances_
plt.barh(X.columns, feature_importance)
plt.xlabel('Importance')
plt.title('Feature Importance for Transmission Rate Prediction')
plt.show()



# In[28]:


# Plot total confirmed cases over time
df_cleaned['Confirmed'].plot(figsize=(12, 6), title="COVID-19 Total Confirmed Cases Over Time")
plt.show()



# In[29]:


# Calculate growth rate of cases
df_cleaned['growth_rate'] = df_cleaned['Confirmed'].pct_change()  # Percentage change
df_cleaned['growth_rate'].plot(figsize=(12, 6), title="COVID-19 Growth Rate Over Time")
plt.show()



# In[114]:


# Principal Component Analysis (PCA) for dimensionality reduction and visualization
pca = PCA(n_components=2)
pca_components = pca.fit_transform(df_cleaned[['Confirmed', 'New cases', 'New deaths', 'New recovered']])


# In[35]:


# Plot PCA components
pca_df = pd.DataFrame(pca_components, columns=['PC1', 'PC2'])
plt.scatter(pca_df['PC1'], pca_df['PC2'], c=df_cleaned['transmission_rate'], cmap='viridis')
plt.colorbar(label='Transmission Rate')
plt.xlabel('PC1')
plt.ylabel('PC2')
plt.title('PCA Analysis of Transmission Influencing Factors')
plt.show()


# In[116]:


# Identify other important factors through further regression or analysis
# Example: including 'New recovered' in the model
X_extended = df_cleaned[['Confirmed', 'New cases', 'New deaths', 'New recovered']]  # More features
model_extended = LinearRegression()
model_extended.fit(X_extended, y)

print("\nExtended Linear Regression Coefficients:")
print(f"Coefficients: {model_extended.coef_}")
print(f"Intercept: {model_extended.intercept_}")



# In[117]:


# Visualize important trends like recovery rates, CFR, etc.
df_cleaned['case_fatality_rate'] = (df_cleaned['Deaths'] / df_cleaned['Confirmed']) * 100
df_cleaned['recovery_rate'] = (df_cleaned['Recovered'] / df_cleaned['Confirmed']) * 100



# In[38]:


df_cleaned.columns


# In[39]:


# Create a default date range if missing
df_cleaned['Date'] = pd.date_range(start='2020-01-01', periods=len(df_cleaned), freq='D')
df_cleaned['Date']


# In[40]:


# Verify and fix the 'Date' column
print("Available columns in the dataset:")
print(df_cleaned.columns)



# In[41]:


# Ensure 'Date' exists or rename the relevant column
df_cleaned.rename(columns=lambda x: x.strip(), inplace=True)
if 'Date' not in df_cleaned.columns:
    raise ValueError("The dataset does not have a 'Date' column or a date-related field.")




# In[42]:


# Convert 'Date' to datetime format
df_cleaned['Date'] = pd.to_datetime(df_cleaned['Date'], errors='coerce')
if df_cleaned['Date'].isnull().any():
    print("Warning: Invalid dates found. These rows will be dropped.")
    df_cleaned = df_cleaned.dropna(subset=['Date'])



# In[43]:


# Set 'Date' as the index
df_cleaned.set_index('Date', inplace=True)


# In[44]:


# Ensure the index is unique
if not df_cleaned.index.is_unique:
    df_cleaned = df_cleaned[~df_cleaned.index.duplicated(keep='first')]



# In[45]:


# Calculate CFR and Recovery Rate
df_cleaned['case_fatality_rate'] = (df_cleaned['Deaths'] / df_cleaned['Confirmed']) * 100
df_cleaned['recovery_rate'] = (df_cleaned['Recovered'] / df_cleaned['Confirmed']) * 100


# In[46]:


# Plot CFR and Recovery Rate
plt.figure(figsize=(12, 6))
sns.lineplot(x=df_cleaned.index, y=df_cleaned['case_fatality_rate'], label='CFR', color='red')
sns.lineplot(x=df_cleaned.index, y=df_cleaned['recovery_rate'], label='Recovery Rate', color='green')
plt.title('Case Fatality Rate and Recovery Rate Over Time')
plt.xlabel('Date')
plt.ylabel('Rate (%)')
plt.legend()


# In[47]:


# Plot Case Fatality Rate (CFR) and Recovery Rate
plt.figure(figsize=(12, 6))
sns.lineplot(x=df_cleaned.index, y=df_cleaned['case_fatality_rate'], label='CFR')
sns.lineplot(x=df_cleaned.index, y=df_cleaned['recovery_rate'], label='Recovery Rate')
plt.title('Case Fatality Rate and Recovery Rate Over Time')
plt.legend()
plt.show()


# In[48]:


# Case Growth Rate
plt.subplot(3, 1, 1)
sns.lineplot(data=df_cleaned, x=df_cleaned.index, y='growth_rate', color='blue', label='Case Growth Rate')
plt.title('COVID-19 Case Growth Rate Over Time')
plt.xlabel('Date')
plt.ylabel('Growth Rate (%)')
plt.legend()


# In[49]:


# Recovery Rate
plt.subplot(3, 1, 2)
sns.lineplot(data=df_cleaned, x=df_cleaned.index, y='recovery_rate', color='green', label='Recovery Rate')
plt.title('COVID-19 Recovery Rate Over Time')
plt.xlabel('Date')
plt.ylabel('Rate (%)')
plt.legend()


# In[50]:


# Calculate the Mortality Rate relative to Confirmed Cases
df_cleaned['mortality_rate'] = (df_cleaned['Deaths'] / df_cleaned['Confirmed']) * 100


# In[51]:


# Verify that the column is added
print("Mortality Rate added to dataset:")
print(df_cleaned[['Confirmed', 'Deaths', 'mortality_rate']].head())



# In[52]:


# Plot the Mortality Rate
import seaborn as sns
import matplotlib.pyplot as plt

plt.figure(figsize=(10, 6))
sns.lineplot(x=df_cleaned.index, y=df_cleaned['mortality_rate'], color='red', label='Mortality Rate')
plt.title('COVID-19 Mortality Rate Over Time')
plt.xlabel('Date')
plt.ylabel('Mortality Rate (%)')
plt.legend()
plt.show()


# In[53]:


# case_fatality_rate
plt.subplot(3, 1, 2)
sns.lineplot(data=df_cleaned, x=df_cleaned.index, y='case_fatality_rate', color='green', label='fatality_rate')
plt.title('COVID-19 case_fatality_rate Over Time')
plt.xlabel('Date')
plt.ylabel('Rate (%)')
plt.legend()


# In[54]:


df_cleaned.columns


# In[118]:


#  Summary Statistics for Key Metrics
print("Summary Statistics:")
print(df_cleaned[['growth_rate', 'recovery_rate', 'mortality_rate','case_fatality_rate']].describe())


# In[56]:


import seaborn as sns
from statsmodels.tsa.arima.model import ARIMA
from sklearn.metrics import mean_absolute_error



# In[57]:


from sklearn.metrics import classification_report, accuracy_score, confusion_matrix
from sklearn.metrics import mean_absolute_error



# In[58]:


df_cleaned.columns


# In[59]:


# Create a default date range if missing
df_cleaned['Date'] = pd.date_range(start='2020-01-01', periods=len(df_cleaned), freq='D')
df_cleaned['Date']


# In[60]:


# Inspect the first few rows of the 'Date' column
print("First few rows of the 'Date' column:\n", df_cleaned['Date'].head())




# In[119]:


#Set 'Date' column as index
df_cleaned.set_index('Date', inplace=True)


# In[120]:


# Verify that the 'Date' column is now the index
print("Dataset with 'Date' as index:\n", df_cleaned.head())



# In[124]:


#Resample the data (if necessary) to daily frequency and sum the 'Confirmed' cases
df_daily = df_cleaned['Confirmed'].resample('D').sum()



# In[119]:


# Check if the 'Date' column exists and create it if missing
if 'Date' not in df_cleaned.columns:
    # Create a default date range if missing
    df_cleaned['Date'] = pd.date_range(start='2020-01-01', periods=len(df_cleaned), freq='D')



# In[127]:


# Strip any leading/trailing spaces from column names
df_cleaned.columns = df_cleaned.columns.str.strip()




# In[128]:


# Ensure the 'Date' column is in datetime format
df_cleaned['Date'] = pd.to_datetime(df_cleaned['Date'], errors='coerce')



# In[129]:


# Drop rows with NaT values in the 'Date' column
df_cleaned = df_cleaned.dropna(subset=['Date'])


# In[120]:


#  Set 'Date' column as index for time series analysis
df_cleaned.set_index('Date', inplace=True)


# In[121]:


#  Time Series Forecasting for Confirmed Cases (using ARIMA)
# Resample to daily frequency and sum the Confirmed cases
df_daily = df_cleaned['Confirmed'].resample('D').sum()



# In[67]:


# Plotting the time series to inspect
plt.figure(figsize=(10, 6))
df_daily.plot(label='Confirmed Cases')
plt.title('Confirmed COVID-19 Cases Over Time')
plt.xlabel('Date')
plt.ylabel('Confirmed Cases')
plt.legend()
plt.show()


# In[68]:


from sklearn.model_selection import train_test_split


# In[122]:


#  Split into train and test sets (80% train, 20% test)
train_size = int(len(df_daily) * 0.8)
train, test = df_daily[:train_size], df_daily[train_size:]


# In[70]:


# Fit an ARIMA model on the training set
model = ARIMA(train, order=(5, 1, 0))  # ARIMA(p,d,q)
model_fit = model.fit()


# In[71]:


# Forecast the next n days (e.g., 30 days)
forecast_steps = len(test)
forecast = model_fit.forecast(steps=forecast_steps)


# In[72]:


# Plot the predictions and actual values
plt.figure(figsize=(10, 6))
plt.plot(train, label='Training Data')
plt.plot(test, label='Actual Cases')
plt.plot(test.index, forecast, label='Predicted Cases', linestyle='--')
plt.title('ARIMA Model for Case Forecasting')
plt.xlabel('Date')
plt.ylabel('Confirmed Cases')
plt.legend()
plt.show()


# In[147]:


# Calculate Mean Absolute Error (MAE) for evaluation
mae = mean_absolute_error(test, forecast)
print(f'Mean Absolute Error (MAE) for ARIMA Model: {mae}')



# In[148]:


# Classification Model for Risk Analysis using Random Forest
# Create a high_risk column based on a threshold for active cases
risk_threshold = 5000  # Define a threshold for high risk
df_cleaned['high_risk'] = (df_cleaned['Active'] > risk_threshold).astype(int)



# In[149]:


# Select features for the classification model
features = ['Confirmed', 'Deaths', 'Recovered', 'New cases', 'New deaths', 'New recovered']
X = df_cleaned[features]
y = df_cleaned['high_risk']


# In[150]:


# Split data into training and test sets
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)


# In[151]:


# Train a Random Forest Classifier
rf_model = RandomForestClassifier(n_estimators=100, random_state=42)
rf_model.fit(X_train, y_train)


# In[152]:


# Predict on the test set
y_pred = rf_model.predict(X_test)


# In[153]:


# Evaluate the classification model
print("Classification Report:")
print(classification_report(y_test, y_pred))

print("Confusion Matrix:")
print(confusion_matrix(y_test, y_pred))

print(f'Accuracy: {accuracy_score(y_test, y_pred)}')



# In[154]:


# Plot feature importance for risk classification
feature_importances = rf_model.feature_importances_
sns.barplot(x=features, y=feature_importances)
plt.title('Feature Importance for Risk Classification')
plt.ylabel('Importance')
plt.xlabel('Features')
plt.xticks(rotation=45)
plt.show()


# In[155]:


#  Time Series Forecasting Results (ARIMA Model)
# Plot the actual vs predicted cases (train, test, and forecast)
plt.figure(figsize=(12, 6))
plt.plot(df_daily.index[:train_size], train, label='Training Data')
plt.plot(df_daily.index[train_size:], test, label='Actual Cases')
plt.plot(test.index, forecast, label='Predicted Cases', linestyle='--')
plt.title('ARIMA Model for Case Forecasting')
plt.xlabel('Date')
plt.ylabel('Confirmed Cases')
plt.legend()
plt.show()



# In[156]:


#Residual Analysis for ARIMA Model
# Residuals are the difference between actual values and predicted values
residuals = test - forecast


# In[157]:


# Plotting the residuals
plt.figure(figsize=(12, 6))
plt.plot(test.index, residuals)
plt.title('Residuals of ARIMA Model')
plt.xlabel('Date')
plt.ylabel('Residuals')
plt.show()


# In[158]:


# Plot the histogram of residuals
plt.figure(figsize=(10, 6))
sns.histplot(residuals, bins=30, kde=True)
plt.title('Distribution of Residuals')
plt.xlabel('Residuals')
plt.ylabel('Frequency')
plt.show()



# In[159]:


# Correlation Matrix of the dataset (EDA)
# Calculate the correlation matrix
corr_matrix = df_cleaned[['Confirmed', 'Deaths', 'Recovered', 'Active', 'New cases', 'New deaths', 'New recovered']].corr()


# In[160]:


# Plot the heatmap for the correlation matrix
plt.figure(figsize=(10, 6))
sns.heatmap(corr_matrix, annot=True, cmap='coolwarm', fmt='.2f', linewidths=0.5)
plt.title('Correlation Matrix of Key Features')
plt.show()



# In[161]:


# 4. Distribution of Key Variables (EDA)
# Plot distribution of key features like Confirmed, Deaths, and Active cases
fig, axes = plt.subplots(1, 3, figsize=(18, 6))



# In[162]:


# Distribution of Confirmed cases
sns.histplot(df_cleaned['Confirmed'], bins=50, kde=True, ax=axes[0])
axes[0].set_title('Distribution of Confirmed Cases')



# In[163]:


# Distribution of Deaths
sns.histplot(df_cleaned['Deaths'], bins=50, kde=True, ax=axes[1])
axes[1].set_title('Distribution of Deaths')



# In[164]:


# Distribution of Active cases
sns.histplot(df_cleaned['Active'], bins=50, kde=True, ax=axes[2])
axes[2].set_title('Distribution of Active Cases')

plt.tight_layout()
plt.show()


# In[165]:


#Feature Importance from Random Forest Model (Risk Classification)
# Plot feature importance from the trained Random Forest model
feature_importances = rf_model.feature_importances_



# In[166]:


# Create a bar plot to visualize feature importance
plt.figure(figsize=(10, 6))
sns.barplot(x=features, y=feature_importances)
plt.title('Feature Importance for Risk Classification')
plt.ylabel('Importance')
plt.xlabel('Features')
plt.xticks(rotation=45)
plt.show()



# In[167]:


# Confusion Matrix for Random Forest Classification
# Plotting the confusion matrix
from sklearn.metrics import ConfusionMatrixDisplay
cm = confusion_matrix(y_test, y_pred)
disp = ConfusionMatrixDisplay(confusion_matrix=cm, display_labels=['Low Risk', 'High Risk'])
disp.plot(cmap='Blues')
plt.title('Confusion Matrix for Risk Classification')
plt.show()



# In[168]:


from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, confusion_matrix, classification_report, roc_curve, auc


# In[169]:


#  Accuracy
accuracy = accuracy_score(y_test, y_pred)
print(f"Accuracy: {accuracy:.4f}")



# In[170]:


# Precision
precision = precision_score(y_test, y_pred, average='weighted')  # Adjusted for multi-class
print(f"Precision: {precision:.4f}")


# In[135]:


#  Recall
recall = recall_score(y_test, y_pred, average='weighted')  # Adjusted for multi-class
print(f"Recall: {recall:.4f}")



# In[136]:


# 4. F1-Score
f1 = f1_score(y_test, y_pred, average='weighted')  # Adjusted for multi-class
print(f"F1-Score: {f1:.4f}")


# In[137]:


#  Confusion Matrix
cm = confusion_matrix(y_test, y_pred)
print("\nConfusion Matrix:")
print(cm)


# In[103]:


# 6. Classification Report
print("\nClassification Report:")
print(classification_report(y_test, y_pred))


# In[ ]:





# In[ ]:





# In[ ]:




